# Machine_Learning_LectureNotes
Machine Learning lecture notes in Turkish
